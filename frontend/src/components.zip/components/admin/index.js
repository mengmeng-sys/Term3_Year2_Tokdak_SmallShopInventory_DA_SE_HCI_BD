// frontend/src/components/admin/index.js
export { default as ShopCard } from './ShopCard';
export { default as UserRow } from './UserRow';