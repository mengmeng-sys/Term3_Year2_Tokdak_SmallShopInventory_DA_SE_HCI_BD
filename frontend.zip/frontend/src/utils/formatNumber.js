export const formatPrice = (price) => {
  return `$${parseFloat(price).toFixed(2)}`;
};

export const formatQuantity = (qty) => {
  return parseInt(qty).toLocaleString();
};
